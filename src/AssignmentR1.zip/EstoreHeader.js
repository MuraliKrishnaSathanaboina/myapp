function EstoreHeader(){
    return(<div className="header"><h1><center>THE LANDMARK TOUR</center></h1></div>)
}
export default EstoreHeader